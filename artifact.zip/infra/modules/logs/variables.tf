variable "name" {
  type = string
}

